--q2
SELECT count(UserID)
FROM userInfo u
WHERE u.Location = "New York";