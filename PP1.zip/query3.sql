--q3
SELECT count(ItemID)
FROM item i
WHERE i.CategoryNum = 4;
