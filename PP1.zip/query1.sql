--q1
SELECT count(UserID)
FROM userInfo;