--q7
SELECT count(distinct Categories)
FROM catBidInfo c
WHERE c.Amount > 100